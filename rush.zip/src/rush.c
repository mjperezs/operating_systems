/* 

Maria Jose Perez Smith U77568172

The program is a simple shell program that supports 
built-in commands, external commands, and output redirection. 
The shell prompts for new input after each command is completed
*/

//necessary libraries declared
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

// constant variables declared
#define MAX_LINE 256  

char** paths = NULL;  // dynamically allocate space for executable search paths
int path_count = 0;   // store the number of paths

// function to print error message
void print_error() {
    const char error_message[] = "An error has occurred\n";
    write(STDERR_FILENO, error_message, strlen(error_message));
}

// built-in command: cd
void builtin_cd(char** args, int argc) {
    if (argc != 2) {
        print_error();
        return;
    }
    if (chdir(args[1]) != 0) {
        print_error();
    }
}

// built-in command: path
void builtin_path(char** args, int argc) {
    // free previously set paths
    for (int i = 0; i < path_count; i++) {
        free(paths[i]);
    }
    free(paths);

    // allocate memory for new paths
    paths = (char**)malloc((argc - 1) * sizeof(char*));
    path_count = 0;

    for (int i = 1; i < argc; i++) {
        paths[path_count] = strdup(args[i]);
        path_count++;
    }
}

// check if the command is a built-in command
int is_builtin_command(char** args, int argc) {
    if (strcmp(args[0], "exit") == 0) {
        if (argc != 1) {
            print_error();
        } else {
            exit(0);
        }
        return 1;
    } else if (strcmp(args[0], "cd") == 0) {
        builtin_cd(args, argc);
        return 1;
    } else if (strcmp(args[0], "path") == 0) {
        builtin_path(args, argc);
        return 1;
    }
    return 0;
}

// handle output redirection
int handle_redirection(char* output_file) {
    if (output_file) {
        int fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH);
        if (fd == -1) {
            print_error();
            return -1;  // indicate an error occurred
        }
        if (dup2(fd, STDOUT_FILENO) == -1) {
            print_error();
            close(fd);
            return -1;  // indicate an error occurred
        }
        close(fd);
    }
    return 0;
}

// execute external commands
void run_command(char** args, int argc, char* output_file) {
    pid_t pid = fork();

    if (pid == 0) {
        // child process
        if (handle_redirection(output_file) == -1) {
            exit(1);  // redirection fails
        }

        // try each path
        for (int i = 0; i < path_count; i++) {
            char exec_path[MAX_LINE];
            snprintf(exec_path, sizeof(exec_path), "%s/%s", paths[i], args[0]);
            execv(exec_path, args);
        }
        print_error();  // execv fails
        exit(1);
    } else if (pid < 0) {
        // fork failed
        print_error();
    } else {
        // parent process
        wait(NULL);  // wait for the child process to complete
    }
}

// parse input commands
int parse_input(char* line, char*** args_ptr, char** output_file) {
    int argc = 0;
    char* token;
    int redirection_count = 0;

    // dynamically allocate memory for arguments
    char** args = (char**)malloc(sizeof(char*) * MAX_LINE);  // Rough estimate for initial allocation

    // parse the command and handle redirection
    while ((token = strsep(&line, " \t\n")) != NULL) {
        if (strlen(token) == 0) continue;  // skip empty tokens

        if (strcmp(token, ">") == 0) {
            redirection_count++;
            if (redirection_count > 1) {
                print_error();
                free(args);
                return -1;  // error if multiple redirections are provided
            }
            token = strsep(&line, " \t\n");
            if (!token || strlen(token) == 0) {
                print_error();
                free(args);
                return -1;  // error if no output file is provided
            }
            *output_file = token;

            // check if there's no command before >
            if (argc == 0) {
                print_error();
                free(args);
                return -1;  // error if redirection is used without a preceding command
            }

            // check if there are any arguments after redirection
            token = strsep(&line, " \t\n");
            if (token != NULL && strlen(token) > 0) {
                print_error();
                free(args);
                return -1;  // error if arguments are provided after redirection
            }
        } else {
            args[argc++] = token;
        }
    }

    args[argc] = NULL;  // null-terminate the argument list
    *args_ptr = args;
    return argc;
}


// execute parallel commands
void execute_parallel_commands(char* line) {
    char* cmd;
    char* rest = line;
    int cmd_count = 0;
    pid_t* pids = malloc(sizeof(pid_t) * MAX_LINE);  // allocate space for child process IDs

    // parse each command separated by '&'
    while ((cmd = strsep(&rest, "&")) != NULL) {
        char** args = NULL;
        char* output_file = NULL;
        int arg_count = parse_input(cmd, &args, &output_file);

        if (arg_count <= 0) continue;  // skip empty commands

        if (is_builtin_command(args, arg_count)) {
            free(args);
            continue; // skip built-in commands
        }

        pid_t pid = fork();
        if (pid == 0) {
            if (handle_redirection(output_file) == -1) {
                free(args);
                exit(1);  // redirection fails
            }

            // try each path
            for (int j = 0; j < path_count; j++) {
                char exec_path[MAX_LINE];
                snprintf(exec_path, sizeof(exec_path), "%s/%s", paths[j], args[0]);
                execv(exec_path, args);
            }
            print_error();  // execv fails
            free(args);
            exit(1);
        } else if (pid < 0) {
            print_error();  // fork failed
        } else {
            pids[cmd_count++] = pid;  // store child PID
        }
        free(args);
    }

    // wait for all child processes to complete
    for (int i = 0; i < cmd_count; i++) {
        waitpid(pids[i], NULL, 0);
    }
    free(pids);  // free the dynamically allocated memory for pids
}

int main(int argc, char* argv[]) {
    paths = (char**)malloc(sizeof(char*) * 1);  // allocate space for one initial path
    paths[0] = strdup("/bin");  
    path_count = 1;

    if (argc > 1) {
        print_error();  // no arguments are allowed
        exit(1);
    }
    //prompt the user for input
    while (1) {
        printf("rush> ");
        fflush(stdout);
        char* line = NULL;
        size_t len = 0;

        // read input from the user
        if (getline(&line, &len, stdin) == -1) {
            print_error();
            free(line);
            continue;
        }

        if (strchr(line, '&') != NULL) {
            // handle parallel commands
            execute_parallel_commands(line);
        } else {
            // handle single command
            char** args = NULL;
            char* output_file = NULL;
            int arg_count = parse_input(line, &args, &output_file);

            if (arg_count == 0) {
                free(line);  // empty command
                continue;
            }

            if (arg_count > 0 && !is_builtin_command(args, arg_count)) {
                run_command(args, arg_count, output_file); //run external command
            }
            free(args);
        }

        free(line);  // free the input buffer
    }

    return 0;
}
