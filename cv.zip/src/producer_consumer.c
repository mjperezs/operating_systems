//Maria Jose Perez U77568172
/*Description: this code is a producer-consumer program that uses a circular buffer to store characters 
produced by a producer thread and consumed by a consumer thread. The producer reads input from the user 
and stores it in the buffer, while the consumer reads characters from the buffer and prints them to the console. 
The producer thread will signal the consumer thread when it has finished producing characters, and the consumer thread 
will exit when it has consumed all characters and the producer has finished producing. The program will continue to prompt 
the user for input until the user types "exit" to quit.
*/

//headers
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>

//defining constants
#define BUFFER_SIZE 15
#define MAX_INPUT 50

//circular buffer
typedef struct {
    char data[BUFFER_SIZE];
    int head;       // Where to read from
    int tail;       // Where to write to
    int count;      // Current number of items in buffer
    
    //synchronization primitives
    pthread_mutex_t mutex;
    pthread_cond_t not_full;
    pthread_cond_t not_empty;
    
    //checks if completed
    int production_completed;
} CircularBuffer;

//initialize buffer
void buffer_init(CircularBuffer *buffer);

//producer thread
void* producer(void *arg) {
    //casts argument to buffer and input
    CircularBuffer *buffer = (CircularBuffer*)arg;
    char *input = (char*)arg + sizeof(CircularBuffer);
    
    //iterate through input
    for (int i = 0; input[i] != '\0'; i++) {
        pthread_mutex_lock(&buffer->mutex);
        
        //wait while buffer is full
        while (buffer->count == BUFFER_SIZE) {
            pthread_cond_wait(&buffer->not_full, &buffer->mutex);
        }
        
        //store character in buffer
        buffer->data[buffer->tail] = input[i];
        printf("Produced: %c\n", input[i]);
        
        //updates buffer tracking
        buffer->tail = (buffer->tail + 1) % BUFFER_SIZE;
        buffer->count++;
        
        //signal that buffer is not empty
        pthread_cond_signal(&buffer->not_empty);
        //unlock mutex
        pthread_mutex_unlock(&buffer->mutex);
    }
    
    //signals that production is complete
    pthread_mutex_lock(&buffer->mutex);
    buffer->production_completed = 1;
    printf("Producer: done\n");
    
    //signal that buffer is not empty
    pthread_cond_signal(&buffer->not_empty);
    pthread_mutex_unlock(&buffer->mutex);
    
    return NULL;
}

//consumer thread
void* consumer(void *arg) {
    //casts argument to buffer
    CircularBuffer *buffer = (CircularBuffer*)arg;

    //iterate through buffer
    while (1) {
        //lock mutex
        pthread_mutex_lock(&buffer->mutex);
        
        //wait while buffer is empty
        while (buffer->count == 0 && !buffer->production_completed) {
            pthread_cond_wait(&buffer->not_empty, &buffer->mutex);
        }
        
        //check if buffer is empty and production is complete
        if (buffer->count == 0 && buffer->production_completed) {
            printf("Consumer: done\n");
            pthread_mutex_unlock(&buffer->mutex);
            break;
        }
        
        //consume character from buffer
        char ch = buffer->data[buffer->head];
        printf("Consumed: %c\n", ch);
        
        //updates buffer tracking
        buffer->head = (buffer->head + 1) % BUFFER_SIZE;
        buffer->count--;
        
        //signal that buffer is not full
        pthread_cond_signal(&buffer->not_full);
        //unlock mutex
        pthread_mutex_unlock(&buffer->mutex);
    }
    
    return NULL;
}

int main() {
    //loop to get user input
    while (1) {
        char input[1024]; //buffer for user input
        char truncated_input[MAX_INPUT + 1]; // truncated input
        
        //prompt user for input
        printf("Enter input (type 'exit' to quit): ");
        //get user input
        fgets(input, sizeof(input), stdin);
        
        //remove newline character
        input[strcspn(input, "\n")] = 0;
        
        //check if user wants to exit the program
        if (strcmp(input, "exit") == 0) {
            //exits the program
            printf("Parent: done\n");
            break; //exit loop
        }
        
        //truncate input if it exceeds the maximum length
        strncpy(truncated_input, input, MAX_INPUT);
        truncated_input[MAX_INPUT] = '\0'; //adds null-terminate string

  
        printf("Input: %s\n", truncated_input); //prints truncated input
        printf("Count: %zu characters\n", strlen(truncated_input)); //prints number of characters
        
        //allocate memory for buffer and input
        size_t total_size = sizeof(CircularBuffer) + strlen(truncated_input) + 1;
        void *memory = malloc(total_size);
        
        //initialize buffer
        CircularBuffer *buffer = (CircularBuffer*)memory;
        
        //initialize buffer
        pthread_mutex_init(&buffer->mutex, NULL); //initialize mutex
        pthread_cond_init(&buffer->not_full, NULL);//initialize condition variable
        pthread_cond_init(&buffer->not_empty, NULL); //initialize condition variable
        
        //initialize buffer
        buffer->head = 0;
        buffer->tail = 0;
        buffer->count = 0; 
        buffer->production_completed = 0; 
        
        //copy input to memory
        strcpy((char*)memory + sizeof(CircularBuffer), truncated_input);
        
        //create producer and consumer threads
        pthread_t producer_thread, consumer_thread;
        pthread_create(&producer_thread, NULL, producer, memory);
        pthread_create(&consumer_thread, NULL, consumer, buffer);
        
        //wait for threads to finish
        pthread_join(producer_thread, NULL);
        pthread_join(consumer_thread, NULL);
        
        //destroy synchronization primitives
        pthread_mutex_destroy(&buffer->mutex);
        pthread_cond_destroy(&buffer->not_full);
        pthread_cond_destroy(&buffer->not_empty);
        free(memory); //free memory
    }
    
    return 0;
}